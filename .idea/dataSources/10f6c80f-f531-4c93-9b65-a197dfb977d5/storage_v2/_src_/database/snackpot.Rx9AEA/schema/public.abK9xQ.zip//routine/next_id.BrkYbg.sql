create function next_id() returns bigint
    language plpgsql
as
$$ DECLARE our_epoch bigint := 1636331031000; result bigint; seq_id bigint; now_millis bigint; shard_id int := 20; BEGIN SELECT nextval('table_id_seq') % 1024 INTO seq_id; SELECT FLOOR(EXTRACT(EPOCH FROM clock_timestamp()) * 1000) INTO now_millis; result := (now_millis - our_epoch) << 22;result := result | (shard_id << 10); result := result | (seq_id); RETURN result; END; $$;

alter function next_id() owner to vlad;

